import { useQuery } from "@tanstack/react-query";
import { useCallback, useEffect, useState } from "react";
import { Navigate, Route, Routes, useNavigate } from "react-router";
import { api, refreshAll } from "../lib/api";
import { loadTelegram, type TgWebApp } from "./telegram";
import { AddSheet, TgProjects, TgToday, TgUpcoming } from "./screens";
import { TgTask } from "./TgTask";

type Auth = "checking" | "ok" | "outside" | "denied";

/** Telegram Mini App shell (Paper style). Lives at /tg/*. Colours come from Telegram's theme. */
export function MiniApp() {
  const [tg, setTg] = useState<TgWebApp | null>(null);
  const [auth, setAuth] = useState<Auth>("checking");
  const [dark, setDark] = useState(window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false);
  const [adding, setAdding] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      const w = await loadTelegram();
      if (!alive) return;
      setTg(w);
      if (w) {
        w.ready();
        w.expand();
        setDark(w.colorScheme === "dark");
        const onTheme = () => setDark(w.colorScheme === "dark");
        w.onEvent("themeChanged", onTheme);
      }
      const me = await api.me().catch(() => ({ authenticated: false }));
      if (me.authenticated) return alive && setAuth("ok");
      if (!w) return alive && setAuth("outside");
      try {
        await api.loginTelegram(w.initData);
        await refreshAll();
        if (alive) setAuth("ok");
      } catch {
        if (alive) setAuth("denied");
      }
    })();
    return () => { alive = false; };
  }, []);

  if (auth !== "ok") {
    const msg =
      auth === "checking" ? "Loading…" : auth === "denied" ? "This Telegram account isn't allowed. Add your user id to TELEGRAM_ALLOWED_USER_IDS." : "Open OmniCore from the Telegram bot (the Open button), or sign in on the web app first.";
    return (
      <div className={`tg ${dark ? "tg-dark" : ""} flex items-center justify-center px-8 text-center font-sans`}>
        <p className="text-[15px]" style={{ color: "var(--tg-hint)" }}>{msg}</p>
      </div>
    );
  }
  return (
    <div className={`tg ${dark ? "tg-dark" : ""} flex flex-col font-sans`}>
      <Routes>
        <Route index element={<Tabs tab="today" tg={tg} onAdd={() => setAdding(true)} adding={adding} />} />
        <Route path="upcoming" element={<Tabs tab="upcoming" tg={tg} onAdd={() => setAdding(true)} adding={adding} />} />
        <Route path="projects" element={<Tabs tab="projects" tg={tg} onAdd={() => setAdding(true)} adding={adding} />} />
        <Route path="task/:id" element={<TgTask tg={tg} />} />
        <Route path="*" element={<Navigate to="/tg" replace />} />
      </Routes>
      {adding && <AddSheet tg={tg} onClose={() => setAdding(false)} />}
    </div>
  );
}

function Tabs({ tab, tg, onAdd, adding }: { tab: "today" | "upcoming" | "projects"; tg: TgWebApp | null; onAdd: () => void; adding: boolean }) {
  const navigate = useNavigate();
  const today = useQuery({ queryKey: ["today"], queryFn: api.today });
  // Native Telegram main button = "New task" on list screens (hidden while the add sheet owns it).
  const click = useCallback(() => onAdd(), [onAdd]);
  useEffect(() => {
    if (!tg || adding) return;
    tg.BackButton.hide();
    tg.MainButton.setText("New task").show().enable();
    tg.MainButton.onClick(click);
    return () => { tg.MainButton.offClick(click); };
  }, [tg, click, adding]);
  const tabs = [["today", "Today", "/tg"], ["upcoming", "Upcoming", "/tg/upcoming"], ["projects", "Projects", "/tg/projects"]] as const;
  return (
    <>
      <div className="flex flex-col gap-3 px-5 pb-2 pt-5">
        <div role="tablist" aria-label="Views" className="grid grid-cols-3 gap-1 rounded-xl p-1" style={{ background: "var(--tg-secondary)" }}>
          {tabs.map(([id, label, to]) => (
            <button key={id} role="tab" aria-selected={tab === id} type="button" onClick={() => navigate(to)} className="rounded-[9px] py-2 text-[14px] font-medium" style={tab === id ? { background: "var(--tg-section)", color: "var(--tg-fg)", boxShadow: "0 1px 2px rgba(0,0,0,.08)" } : { color: "var(--tg-hint)" }}>
              {label}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 pb-28">
        {tab === "today" && <TgToday data={today.data} />}
        {tab === "upcoming" && <TgUpcoming today={today.data?.date} />}
        {tab === "projects" && <TgProjects />}
      </div>
      {!tg && (
        <div className="fixed inset-x-0 bottom-0 p-4" style={{ background: "linear-gradient(to top, var(--tg-bg) 70%, transparent)" }}>
          <button type="button" onClick={onAdd} className="h-[52px] w-full rounded-[14px] text-[16px] font-semibold" style={{ background: "var(--tg-accent)", color: "var(--tg-accent-fg)" }}>New task</button>
        </div>
      )}
    </>
  );
}
