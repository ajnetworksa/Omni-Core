import { useQuery } from "@tanstack/react-query";
import { Check, ChevronRight, Sun } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router";
import { api, refreshAll } from "../lib/api";
import { dayLabel } from "../lib/format";
import { nagLine, progressOf } from "../lib/nag";
import type { Parsed, TaskCard, TodayBoard } from "../lib/types";
import { haptic, type TgWebApp } from "./telegram";

const pri = (p: number) => (p === 1 ? "!!!" : p === 2 ? "!!" : p === 3 ? "!" : "");

export function TgCheck({ t, size = 24 }: { t: TaskCard; size?: number }) {
  const done = t.status === "done";
  const pct = progressOf(t);
  const toggle = async (e: React.MouseEvent) => {
    e.stopPropagation();
    haptic.tap();
    await api.action(t.id, done ? "reopen" : "done");
    if (!done) haptic.ok();
    await refreshAll();
  };
  const common = { width: size, height: size, borderRadius: 8, flex: "none" as const };
  if (done)
    return (
      <button type="button" aria-label={`Reopen ${t.title}`} onClick={toggle} style={{ ...common, background: "var(--tg-accent)", color: "var(--tg-accent-fg)" }} className="flex items-center justify-center">
        <Check size={14} strokeWidth={3.5} />
      </button>
    );
  if (t.status === "blocked")
    return (
      <button type="button" aria-label={`Complete ${t.title}`} onClick={toggle} style={{ ...common, border: "2px solid #fca5a5", background: "rgba(254,226,226,.6)", color: "#b91c1c" }} className="flex items-center justify-center text-[12px] font-extrabold">
        !
      </button>
    );
  return (
    <button
      type="button"
      aria-label={`Complete ${t.title}`}
      onClick={toggle}
      style={{ ...common, border: `2px solid ${pct ? "var(--tg-accent)" : "color-mix(in oklab, var(--tg-hint) 55%, transparent)"}`, background: pct ? `linear-gradient(to top, var(--tg-accent) ${pct}%, transparent ${pct}%)` : "transparent" }}
    />
  );
}

/** Plain-language status line in Paper's voice ("Reminded 3 times", "Moved from yesterday twice"). */
function paperLine(t: TaskCard): { text: string; warn: boolean } | null {
  if (t.status === "done") return null;
  const n = nagLine(t);
  const parts: string[] = [];
  const pct = progressOf(t);
  if (t.sub.total) parts.push(`${t.sub.done} of ${t.sub.total} steps`);
  else if (pct) parts.push(pct >= 50 && pct < 75 ? "Halfway" : `${pct}% done`);
  if (t.nag && t.nag.sent > 0) parts.push(`reminded ${t.nag.sent === 1 ? "once" : `${t.nag.sent} times`}`);
  else if (t.rolloverCount > 0) parts.push(`moved from yesterday${t.rolloverCount > 1 ? ` ${t.rolloverCount === 2 ? "twice" : `${t.rolloverCount}×`}` : ""}`);
  else if (n && n.text.startsWith("Overdue")) parts.push(n.text.split(" · ")[0]!.toLowerCase());
  if (!parts.length) return t.projectTitle ? { text: t.projectTitle, warn: false } : null;
  const s = parts.join(" · ");
  return { text: s[0]!.toUpperCase() + s.slice(1), warn: !!(t.nag?.sent || t.rolloverCount || n) };
}

export function TgRow({ t, boxed }: { t: TaskCard; boxed?: boolean }) {
  const navigate = useNavigate();
  const line = paperLine(t);
  return (
    <div role="link" tabIndex={0} onClick={() => navigate(`/tg/task/${t.id}`)} onKeyDown={(e) => e.key === "Enter" && navigate(`/tg/task/${t.id}`)} className="flex cursor-pointer gap-3.5 px-4 py-3.5" style={boxed ? undefined : {}}>
      <TgCheck t={t} />
      <span className="flex min-w-0 flex-1 flex-col gap-1">
        <span className={`text-[16px] font-medium leading-snug ${t.status === "done" ? "line-through" : ""}`} style={t.status === "done" ? { color: "var(--tg-hint)" } : undefined}>
          {t.title}
          {pri(t.priority) && <span className="ml-1.5 text-[12px] font-bold" style={{ color: t.priority === 1 ? "var(--tg-danger)" : "var(--tg-warn)" }}>{pri(t.priority)}</span>}
        </span>
        {t.status === "blocked" && t.lastRemark ? (
          <span className="rounded-[10px] px-2.5 py-2 text-[13.5px]" style={{ background: "var(--tg-secondary)" }}>{t.lastRemark.text}</span>
        ) : (
          line && <span className="text-[13.5px]" style={{ color: line.warn ? "var(--tg-warn)" : "var(--tg-hint)" }}>{line.text}</span>
        )}
      </span>
      {t.dueTime && t.status !== "done" && !boxed && <span className="self-center text-[13.5px]" style={{ color: "var(--tg-hint)" }}>{t.dueTime}</span>}
      {boxed && <ChevronRight size={16} className="self-center" style={{ color: "var(--tg-hint)" }} aria-hidden />}
    </div>
  );
}

function Group({ title, children, warn }: { title: string; children: React.ReactNode; warn?: boolean }) {
  return (
    <section aria-label={title} className="flex flex-col gap-2 px-4">
      <h2 className="m-0 flex items-center gap-2 px-1.5 font-display text-[14.5px] font-bold" style={{ color: warn ? "var(--tg-warn)" : "var(--tg-fg)" }}>
        {warn && <span className="h-2 w-2 rounded-full" style={{ background: "var(--tg-warn)" }} />}
        {title}
      </h2>
      {children}
    </section>
  );
}

const Card = ({ children }: { children: React.ReactNode }) => (
  <div className="overflow-hidden rounded-[18px] [&>*+*]:border-t" style={{ background: "var(--tg-section)", boxShadow: "0 1px 3px rgba(0,0,0,.06)", borderColor: "var(--tg-sep)" }}>
    <div className="contents [&>*+*]:border-t [&>*+*]:border-[var(--tg-sep)]">{children}</div>
  </div>
);

export function TgToday({ data }: { data?: TodayBoard }) {
  if (!data) return <p className="px-6 py-10 text-center" style={{ color: "var(--tg-hint)" }}>Loading…</p>;
  const total = data.counts.open + data.counts.done;
  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-col gap-0.5 px-6 pt-2">
        <div className="flex items-center gap-2.5">
          <Sun size={26} style={{ color: "var(--tg-accent)" }} aria-hidden />
          <h1 className="m-0 font-display text-[30px] font-extrabold tracking-tight">Today</h1>
        </div>
        <div className="pl-9 text-[14px]" style={{ color: "var(--tg-hint)" }}>{`${new Date(`${data.date}T12:00:00Z`).toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short", timeZone: "UTC" })} · ${data.counts.done} of ${total} done`}</div>
      </div>
      {data.attention.length > 0 && (
        <Group title="Still waiting on you" warn>
          <Card>{data.attention.map((t) => <TgRow key={t.id} t={t} boxed />)}</Card>
        </Group>
      )}
      {(data.later.length > 0 || data.done.length > 0) && (
        <Group title="Later today">
          <div className="flex flex-col">{[...data.later, ...data.done].map((t) => <TgRow key={t.id} t={t} />)}</div>
        </Group>
      )}
      {data.attention.length + data.later.length + data.done.length === 0 && <p className="px-6 text-center text-[15px]" style={{ color: "var(--tg-hint)" }}>Nothing due today.</p>}
    </div>
  );
}

export function TgUpcoming({ today }: { today?: string }) {
  const q = useQuery({ queryKey: ["upcoming"], queryFn: () => api.upcoming(14) });
  return (
    <div className="flex flex-col gap-5 pt-2">
      <h1 className="m-0 px-6 font-display text-[30px] font-extrabold tracking-tight">Upcoming</h1>
      {q.data?.length === 0 && <p className="px-6 text-[15px]" style={{ color: "var(--tg-hint)" }}>Nothing in the next two weeks.</p>}
      {q.data?.map((g) => (
        <Group key={g.date} title={today ? dayLabel(g.date, today) : g.date}>
          <Card>{g.tasks.map((t) => <TgRow key={t.id} t={t} boxed />)}</Card>
        </Group>
      ))}
    </div>
  );
}

export function TgProjects() {
  const q = useQuery({ queryKey: ["projects"], queryFn: api.projects });
  return (
    <div className="flex flex-col gap-4 pt-2">
      <h1 className="m-0 px-6 font-display text-[30px] font-extrabold tracking-tight">Projects</h1>
      <div className="px-4">
        <Card>
          {q.data?.map((p) => (
            <div key={p.id} className="flex items-center gap-3.5 px-4 py-3.5">
              <svg width="28" height="28" viewBox="0 0 20 20" aria-hidden className="flex-none">
                <circle cx="10" cy="10" r="8" fill="none" stroke="var(--tg-secondary)" strokeWidth="3" />
                <circle cx="10" cy="10" r="8" fill="none" stroke="var(--tg-accent)" strokeWidth="3" strokeDasharray={`${(p.percent / 100) * 50.3} 60`} transform="rotate(-90 10 10)" strokeLinecap="round" />
              </svg>
              <span className="flex flex-1 flex-col">
                <span className="text-[16px] font-medium">{p.title}</span>
                <span className="text-[13.5px]" style={{ color: p.overdue || p.blocked ? "var(--tg-warn)" : "var(--tg-hint)" }}>
                  {[`${p.done} of ${p.total} done`, p.blocked ? `${p.blocked} blocked` : "", p.dueToday ? `${p.dueToday} due today` : ""].filter(Boolean).join(" · ")}
                </span>
              </span>
              <span className="text-[14px] font-semibold" style={{ color: "var(--tg-hint)" }}>{`${p.percent}%`}</span>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

/** Bottom sheet for quick add; the native MainButton becomes "Add". */
export function AddSheet({ tg, onClose }: { tg: TgWebApp | null; onClose: () => void }) {
  const [text, setText] = useState("");
  const [parsed, setParsed] = useState<Parsed | null>(null);
  const today = useQuery({ queryKey: ["today"], queryFn: api.today });
  const ref = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { ref.current?.focus(); }, []);
  useEffect(() => {
    if (!text.trim()) return setParsed(null);
    const id = setTimeout(() => api.parse(text).then(setParsed, () => setParsed(null)), 200);
    return () => clearTimeout(id);
  }, [text]);
  const submit = useCallback(async () => {
    if (!text.trim()) return;
    tg?.MainButton.showProgress();
    try {
      await api.create(text.trim());
      haptic.ok();
      await refreshAll();
      onClose();
    } catch {
      haptic.err();
    } finally {
      tg?.MainButton.hideProgress();
    }
  }, [text, tg, onClose]);
  useEffect(() => {
    if (!tg) return;
    tg.MainButton.setText("Add task").show();
    if (text.trim()) tg.MainButton.enable(); else tg.MainButton.disable();
    tg.MainButton.onClick(submit);
    tg.BackButton.show();
    tg.BackButton.onClick(onClose);
    return () => { tg.MainButton.offClick(submit); tg.BackButton.offClick(onClose); tg.BackButton.hide(); };
  }, [tg, submit, onClose, text]);
  const chips = parsed
    ? [
        parsed.dueDate && today.data ? `${dayLabel(parsed.dueDate, today.data.date)}${parsed.dueTime ? ` ${parsed.dueTime}` : ""}` : null,
        parsed.priority && parsed.priority < 4 ? ["", "Urgent", "High", "Medium"][parsed.priority] : null,
        parsed.recurrence,
        parsed.project,
        ...parsed.tags.map((t) => `#${t}`),
      ].filter(Boolean)
    : [];
  return (
    <div className="fixed inset-0 z-30 flex flex-col justify-end" style={{ background: "rgba(0,0,0,.35)" }} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label="New task" className="anim-in flex flex-col gap-3 rounded-t-[22px] px-5 pb-6 pt-5" style={{ background: "var(--tg-section)" }}>
        <h2 className="m-0 font-display text-[18px] font-bold">New task</h2>
        <label htmlFor="tg-add" className="sr-only">Task</label>
        <textarea id="tg-add" ref={ref} rows={2} value={text} onChange={(e) => setText(e.target.value.replace(/\n/g, " "))} placeholder="Call ISP tomorrow 10:00 !p2 #homelab" className="resize-none rounded-[14px] px-3.5 py-3 text-[16px] outline-none" style={{ background: "var(--tg-secondary)", color: "var(--tg-fg)" }} />
        <div className="flex min-h-7 flex-wrap gap-1.5">
          {chips.map((c) => (
            <span key={c!} className="rounded-full px-2.5 py-1 text-[13px] font-medium" style={{ background: "color-mix(in oklab, var(--tg-accent) 14%, transparent)", color: "var(--tg-link)" }}>{c}</span>
          ))}
          {!chips.length && <span className="text-[13px]" style={{ color: "var(--tg-hint)" }}>Tip: @today, @tomorrow, !p1, #project/name</span>}
        </div>
        {!tg && (
          <button type="button" disabled={!text.trim()} onClick={() => void submit()} className="h-[52px] rounded-[14px] text-[16px] font-semibold disabled:opacity-50" style={{ background: "var(--tg-accent)", color: "var(--tg-accent-fg)" }}>Add task</button>
        )}
      </div>
    </div>
  );
}
